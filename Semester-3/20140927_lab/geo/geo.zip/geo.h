/* geo.h */

float area(int a, int b);
float volume(int a, int b, int c);

/* weight.h*/

float weight(int a, int b, int c, int density);
